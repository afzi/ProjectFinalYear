# CO600 Bird Rings

CO600 project space for smart bird rings project